import React from 'react'
import Dashboard from './pages/Dashboard'
import Login from './pages/Login'
import 'quill/dist/quill.snow.css';
import SelectLogo from './components/SelectLogo';
import EnterOTP from './components/EnterOTP';
export default function App() {
  return (
    <div>
      <Login/>
    </div>
  )
}
